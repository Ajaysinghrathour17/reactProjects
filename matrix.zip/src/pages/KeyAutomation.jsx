import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const KeyAutomation = () => {
  return (

    <div className='adminContainer '>
    <AdminSidebar />

{/* main */}
<main> 
<h1>Keyword Automation </h1>
</main>
</div>
  )
}

export default KeyAutomation