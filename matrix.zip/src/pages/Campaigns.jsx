import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Campaigns = () => {
  return (

    <div className='adminContainer '>
    <AdminSidebar />

{/* main */}
<main> 
<h1>Campaigns</h1>
</main>
</div>
  )
}

export default Campaigns