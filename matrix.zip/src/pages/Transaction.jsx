import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Transaction = () => {
  return (
    <div className='adminContainer '>

      {/* sidebar */}
     <AdminSidebar />

      {/* main */}
      <main> Transaction</main>
    </div>
  )
}

export default Transaction