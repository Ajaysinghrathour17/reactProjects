import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Inbox = () => {
  return (

    <div className='adminContainer '>
    <AdminSidebar />

{/* main */}
<main> 
<h1>Inbox</h1>
</main>
</div>
  )
}

export default Inbox;