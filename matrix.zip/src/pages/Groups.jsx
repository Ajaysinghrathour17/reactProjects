import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Groups = () => {
  return (
    <div className='adminContainer '>
    <AdminSidebar />

{/* main */}
<main> Groups</main>
</div>
  )
}

export default Groups