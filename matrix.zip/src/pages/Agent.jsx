import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Agent = () => {
  return (

    <div className='adminContainer '>
    <AdminSidebar />

{/* main */}
<main> 
<h1>Assign Agent</h1>
</main>
</div>
  )
}

export default Agent