import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Contacts = () => {
  return (
    <div className='adminContainer '>
    <AdminSidebar />

{/* main */}
<main> Contacts</main>
</div>
  )
}

export default Contacts