import React from 'react'
import AdminSidebar from '../components/AdminSidebar'

const Products = () => {
  return (
    <div className='adminContainer '>
        <AdminSidebar />

{/* main */}
<main> <h3>Rest APIs</h3></main>
    </div>
  )
}

export default Products