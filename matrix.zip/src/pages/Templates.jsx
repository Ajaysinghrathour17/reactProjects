import React from 'react'
import AdminSidebar from '../components/AdminSidebar'
const Templates = () => {
    return (
        <div className='adminContainer '>
            <AdminSidebar />

            {/* main */}
            <main>
                <h1>Templates</h1>
            </main>
        </div>
    )
}

export default Templates;


