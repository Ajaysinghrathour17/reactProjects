import Form from "./Form";
import Rm from "./Rm";
import Agent from "./Agent";

function App() {
  

  return (
    <>
    <Form/>
    <Rm/>
    <Agent/>
    </>
  );
}

export default App
