import React from 'react'

const Ajay = () => {
  return (
    <div>Ajay</div>
  )
}

export default Ajay